declare module 'qs';
